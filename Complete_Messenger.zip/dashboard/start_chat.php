<?php include('session.php'); ?>
  
 <?php if(isset($_GET['to'])) { ?>

    <div class="contact-profile">
        <?php
        $user_session_id = $_GET['userId'];
        $senderid = $_GET['to'];
        $Query = mysqli_query($conn,"SELECT * FROM users where userId = '$senderid' ");
        $member_name = mysqli_fetch_array($Query);
        $member_name['userName'];
        ?>
      <img style="width:50px;height:50px;" src="<?php echo $member_name['image']; ?>" alt="" /> 
      
      <p><?php echo $member_name['userName']; ?></p>

      <div class="social-media">
        <i class="fa fa-facebook" aria-hidden="true"></i>
        <i class="fa fa-twitter" aria-hidden="true"></i>
         <i class="fa fa-instagram" aria-hidden="true"></i>
      </div>
    </div>

<script langauge="javascript">

                  setInterval(function(){ 
                  
                  refreshDiv();
                  
                  }, 1000);

            function refreshDiv()
{
             
                  var to = document.getElementById('refresh').value; 
                  // var x = document.getElementById("ddd").innerHTML = to;
            }
        </script>
  
 
    <div id="refresh" class="messages" style="margin-left:10px; max-height:720px; overflow-y:scroll;">
       
      <ul>

          <?php
               

                    $query = "SELECT `users`.`userId` ,  `users`.`userName` , `users`.`image` , `dbo_text`.`type` ,`dbo_text`.`text` ,  `dbo_text`.`to_id` , `dbo_text`.`filepic`, `dbo_text`.`sender_id`  FROM users
                  LEFT JOIN  `kidsbook_kidsbook`.`dbo_text` ON  `users`.`userId` =  `dbo_text`.`sender_id`
                   WHERE  `dbo_text`.`to_id` = '$senderid' or `dbo_text`.`sender_id` = '$senderid' and `dbo_text`.`to_id` = '$senderid' or `dbo_text`.`sender_id` = '$senderid'";
                  $rs = mysqli_query($conn,$query);
                  while($result = mysqli_fetch_array($rs)){

                     $to = $result['to_id']; 
                      $sender =  $result['sender_id'];
                      $readUnred = $result['type'];
           
             ?>
             
               <?php if($user_session_id == $to ) { ?>


          <li class="sent">
          <?php if($result['filepic'] !='' && $result['text'] !='' ){ ?>
               
               <img style="width:30px;height:30px;" src="<?php echo $result['image']; ?>" alt="" /> 
               <div><img class="imgs" style="border-radius:0px;" src="<?php echo $result['filepic']; ?>"/></div>
               <p><?php echo $result['text']; ?> <i class="fal fa-check-double"></i></p>

              <?php } elseif ($result['text'] !='') { ?>

              <img style="width:30px;height:30px;" src="<?php echo $result['image']; ?>" alt="" />
              <p><?php echo $result['text']; ?> <i class="fal fa-check-double"></i></p>
             
              <?php } ?>
         </li>
      

                  <?php } elseif($senderid == $to) { ?>


            
         <li class="replies">
    

           <?php if($result['filepic'] !='' && $result['text'] !='' ){ ?>

             
               
                <img style="width:30px;height:30px;" src="<?php echo $result['image']; ?>" alt="" />
                <div class="contain">
                <img class="imgs"  src="<?php echo $result['filepic']; ?>"/>
                <p><?php echo $result['text']; ?> <i class="fal fa-check-double"></i></p>
                </div>
            
               
              

              <?php } elseif ($result['text'] !='') { ?>
              
              <img style="width:30px;height:30px;" src="<?php echo $result['image']; ?>" alt="" />
              <p><?php echo $result['text']; ?> <i class="fal fa-check-double"></i></p>
             
              <?php } elseif($result['filepic'] !=''){ ?>

                <img style="width:30px;height:30px;" src="<?php echo $result['image']; ?>" alt="" />
               <img id="imges" src="<?php echo $result['filepic']; ?>" alt="" />
              
              <?php } ?>
        </li>
      
                  


              <?php } else {} ?>  

                                         
            <?php } ?>

      </ul>
      <?php //} ?>
    </div>



    
    <div class="message-input">
      <div class="wrap">
        <!-- <input type="text" id="sender" hidden="" value="<?php //echo $xxx; ?>"  class="form-control input-sm chat_input"><br>  -->
     
      <input type="text" hidden onclick="fetchchat(<?php echo $mess; ?>)"  value="<?php echo $senderid; ?>" name="to" id="to" >
      <input type="text" id="chatmsg"  placeholder="Write your message..." />
      <!-- <i class="fa fa-paperclip attachment" aria-hidden="true"></i> -->
        <label class="newbtn" >
        <img src="images/file.png" style="margin-left:50x; width:25px; height:20px;" >
        <input id="pic" hidden="" accept="image/*" type="file" id="imgfile" name="imgfile" onchange="showMyImage(this)">
        </label>
      <!-- <button type="submit" id="send_msg" class="fa fa-paper-plane" value="<?php //echo $senderid; ?>"></button> -->
       <button type="submit" id="btn"  class="btn btn-primary btn-sm" id="btn-chat">Send</button>
      </div>
                       
    </div>

 <?php } ?>


<style>
#frame .content .messages ul li.replies div img {
    /*float: right;*/
    width: 150px;
    border-radius: 20px !important;
    margin: 6px 0 0 8px;
}
#frame .content .messages ul li.replies p {
    background: #f5f5f5;
    /* float: right; */
    /*margin-top: 0px important;*/
    margin-left: 783px !important;
}
</style>

<style>
#imges{
  border-radius: 10px !important;
  width: 130px !important;

}
</style>