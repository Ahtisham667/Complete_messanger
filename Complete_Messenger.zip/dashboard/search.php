<?php

echo $search_id = $_GET['id'];

?>