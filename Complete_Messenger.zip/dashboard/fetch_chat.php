<?php
	      


if(isset($_POST['id']))
{
	echo $mess  = $_POST['id'];
}
else
{
	echo "not ik";
}

?>
<?php// include('session.php'); ?>
<!--  <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Webslesson Tutorial | Convert Data from Mysql to JSON Format using PHP</title>  
      </head>  
      <body>  
           <?php     
           $sql = "SELECT * FROM members";  
           $result = mysqli_query($conn, $sql);  
           $json_array = array();  
           while($row = mysqli_fetch_assoc($result))  
           {  
                $json_array[] = $row;  
           }  
           /*echo '<pre>';  
           print_r(json_encode($json_array));  
           echo '</pre>';*/  
           echo json_encode($json_array);  
           ?>  
      </body>  
 </html>   -->
