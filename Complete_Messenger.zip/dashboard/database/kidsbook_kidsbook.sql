-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 24, 2020 at 10:10 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kidsbook_kidsbook`
--

-- --------------------------------------------------------

--
-- Table structure for table `dbo_text`
--

CREATE TABLE `dbo_text` (
  `id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `to_id` int(11) NOT NULL,
  `text` varchar(1000) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `file` text,
  `m_time` varchar(30) NOT NULL,
  `m_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `chatimage` varchar(200) DEFAULT NULL,
  `filepic` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dbo_text`
--

INSERT INTO `dbo_text` (`id`, `sender_id`, `to_id`, `text`, `content`, `type`, `file`, `m_time`, `m_date`, `chatimage`, `filepic`) VALUES
(0, 31, 5, 'hii', NULL, 'Unread', NULL, '', '2020-08-24 12:55:21', NULL, NULL),
(0, 31, 5, '', NULL, 'Unread', NULL, '', '2020-08-24 12:55:44', NULL, './chat_image/968869607.jpg'),
(0, 31, 8, 'whatsapp bro', NULL, 'Unread', NULL, '', '2020-08-24 13:09:04', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE `friends` (
  `f_id` int(11) NOT NULL,
  `m_id_one` int(11) NOT NULL,
  `m_id_two` int(11) NOT NULL,
  `status` varchar(200) NOT NULL,
  `m_id_action` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friends`
--

INSERT INTO `friends` (`f_id`, `m_id_one`, `m_id_two`, `status`, `m_id_action`) VALUES
(1, 5, 31, 'Accept', 0),
(2, 31, 6, 'Accept', 0),
(3, 31, 7, 'Accept', 0),
(4, 31, 8, 'Accept', 0),
(5, 31, 9, 'Accept', 0),
(6, 31, 11, 'Panding', 0),
(7, 12, 31, 'Panding', 0);

-- --------------------------------------------------------

--
-- Table structure for table `friend_request`
--

CREATE TABLE `friend_request` (
  `frome` varchar(100) NOT NULL,
  `toe` varchar(100) NOT NULL,
  `toe_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friend_request`
--

INSERT INTO `friend_request` (`frome`, `toe`, `toe_name`) VALUES
('5', '6', 'Abdul Sami'),
('15', '6', 'Mir_Aatik_Faizi B6_Admin'),
('11', '31', 'Ghazanfar_Ahmed Admin'),
('5', '16', 'Abdul_Sami Admin'),
('41', '31', 'Saher_salahudin Teacher'),
('41', '40', 'Saher_salahudin Teacher'),
('25', '45', 'Shayaan_Baba B6'),
('25', '44', 'Shayaan_Baba B6'),
('25', '43', 'Shayaan_Baba B6'),
('15', '40', 'Mir_Aatik_Faizi B6_Admin'),
('15', '36', 'Mir_Aatik_Faizi B6_Admin'),
('11', '62', 'Ghazanfar_Ahmed Admin'),
('32', '28', 'Muhmmad_Bilal Admin'),
('32', '29', 'Muhmmad_Bilal Admin'),
('32', '8', 'Muhmmad_Bilal Admin'),
('81', '19', 'Brishk_sharjeel G4'),
('82', '17', 'nufail12'),
('82', '42', 'nufail12'),
('83', '17', 'zamraiz12'),
('84', '17', 'zayyan12');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userId` int(11) NOT NULL,
  `userName` varchar(30) NOT NULL,
  `userEmail` varchar(60) NOT NULL,
  `userPass` varchar(255) NOT NULL,
  `image` varchar(100) NOT NULL,
  `stdName` varchar(50) NOT NULL,
  `gender` varchar(15) NOT NULL,
  `class` varchar(15) NOT NULL,
  `address` varchar(100) NOT NULL,
  `schoolName` varchar(50) NOT NULL,
  `contactNo` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `birthDate` date NOT NULL,
  `DateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userId`, `userName`, `userEmail`, `userPass`, `image`, `stdName`, `gender`, `class`, `address`, `schoolName`, `contactNo`, `city`, `birthDate`, `DateTime`, `status`) VALUES
(5, 'Rao Ahtisham', 'ahtisham', '123', 'images/sami12.jpg', 'Abdul Sami', 'Male', 'Admin', '', '', '', '', '0000-00-00', '2017-12-19 01:08:03', ''),
(6, 'Moosa_Raza ', 'moosa12', '123456', 'images/moosa12.jpg', '', '', '', '', '', '', '', '0000-00-00', '2017-12-19 01:08:03', ''),
(7, 'Mudassir_Zia Admin', 'mudassir12', '123456', 'images/mudassir12.jpg', '', '', '', '', '', '', '', '0000-00-00', '2017-12-19 01:08:03', ''),
(8, 'Muhammad_Saqib Admin', 'saqib12', '123456', 'images/saqib12.jpg', '', '', '', '', '', '', '', '0000-00-00', '2017-12-19 01:08:03', ''),
(9, 'Ubaid_Abbasi Admin', 'ubaid12', '123456', 'images/ubaid12.jpg', '', '', '', '', '', '', '', '0000-00-00', '2017-12-19 01:08:03', ''),
(11, 'Ghazanfar_Ahmed ', 'ghazanfar12', '123456', 'images/dp.png', '', '', '', '', '', '', '', '0000-00-00', '2017-12-19 01:08:03', ''),
(12, 'M_Ehtisham Admin', 'ehtisham12', '123456', 'images/dp.png', '', '', '', '', '', '', '', '0000-00-00', '2017-12-19 01:08:03', ''),
(13, 'Daniyal_Nadeem ', 'daniyal12', '123456', 'images/daniyal12.jpg', '', '', '', '', '', '', '', '0000-00-00', '2017-12-19 01:08:03', ''),
(15, 'Mir_Aatik_Faizi ', 'aatik12', '123456', 'images/aatik12.jpg', '', '', '', '', '', '', '', '0000-00-00', '2017-12-19 01:08:03', ''),
(16, 'Aatik_Friend', 'afriend1', '12334', 'images/dp.png', '', '', '', '', '', '', '', '0000-00-00', '2017-12-19 01:08:03', ''),
(17, 'Mahveen_Asim ', 'mahveen12', '98641', 'images/mahveen12.jpg', '', '', '', '', '', '', '', '0000-00-00', '2017-12-19 01:08:03', ''),
(19, 'Mahveen_Friend', 'mfriend1', '98764', 'images/dp.png', '', '', '', '', '', '', '', '0000-00-00', '2017-12-19 01:08:03', ''),
(20, 'Mahveen_Frien', 'mfriend2', '82465', 'images/dp.png', '', '', '', '', '', '', '', '0000-00-00', '2017-12-19 01:08:03', ''),
(21, 'Mahveen_Friend', 'mfriend3', '64312', 'images/dp.png', '', '', '', '', '', '', '', '0000-00-00', '2017-12-19 01:08:03', ''),
(22, 'Mahveen_Friend', 'mfriend4', '64877', 'images/dp.png', '', '', '', '', '', '', '', '0000-00-00', '2017-12-19 01:08:03', ''),
(23, 'Mahveen_Friend', 'mfriend5', ' 44652', 'images/dp.png', '', '', '', '', '', '', '', '0000-00-00', '2017-12-19 01:08:03', ''),
(24, 'Aatik_Friend', 'afriend2', '125', 'images/daniyal12.jpg', '', '', '', '', '', '', '', '0000-00-00', '2017-12-19 01:08:03', ''),
(25, 'Shayaan_Baba B6', 'afriend3', '412278', 'images/shayan12.jpg', '', '', '', '', '', '', '', '0000-00-00', '2017-12-19 01:08:03', ''),
(26, 'Afreen', 'afreen', '125', 'images/dp.png', 'Aatik Friend', 'Boy', 'B-6', 'karachi', ' Public School', '030XXXXX', 'karachi', '2000-01-01', '2017-12-19 01:08:03', ''),
(27, 'Aatik', 'atif', '123', './files_image/694006921.png', 'Aatik Friend', 'Boy', 'B-6', 'karachi', 'Habib Public School', '0304XXXXXXX', 'karachi', '2000-06-06', '2017-12-19 01:08:03', ''),
(28, 'Murad_Khan Admin', 'Murad09', '123456', 'images/Murad09.jpg', 'Murad Khan', 'Boy', 'Admin', 'Magnificent', 'Magnificent', '030XXXXX', 'karachi', '1986-10-12', '2017-12-19 01:08:03', ''),
(29, 'Mavia_Husnain', 'Mavia07', '123456', 'images/Mavia07.jpg', 'Mavia Husnain', 'Boy', 'Admin', 'Magnificent', 'Magnificent', '030XXXXX', 'karachi', '0000-00-00', '2017-12-19 01:08:03', ''),
(31, ' Fatima', 'fatima', '123', 'images/dp.png', 'Fatima Rais', 'Girl', 'Teacher', 'Orangi Town Haryana Colony Sector 10 Karachi', 'Good Luck Secondary School', '030XXXXX', 'karachi', '1999-10-11', '2017-12-19 01:08:03', ''),
(32, 'Muhmmad_Bilal Admin', 'bilal12', '123456', 'images/bilal12.jpg', 'Muhmmad Bilal', 'Boy', 'Admin', 'Magnificent', 'Magnificent', '030XXXXX', 'karachi', '1988-03-05', '2017-12-19 01:08:03', ''),
(36, 'Rayan_Abid B4', 'rayanabid12', '225438', 'images/dp.png', 'Rayyan Abid', 'Boy', 'B-4', 'karachi', 'Habib Public School', '030XXXXX', 'karachi', '1999-11-11', '2017-12-19 01:08:03', ''),
(37, 'Rayan_Bilal B4', 'rayyanbilal12', '884692', 'images/dp.png', 'Rayyan Bilal', 'Boy', 'Teacher', 'karachi', 'Habib Public School', '030XXXXX', 'karachi', '0000-00-00', '2017-12-19 01:08:03', ''),
(39, 'Arhum_Adnan', 'arhumadnan12', '88745', 'images/dp.png', 'Arhum Adnan', 'Boy', 'Teacher', 'karachi', 'Habib Public School', '030XXXXX', 'karachi', '1999-10-08', '2017-12-19 01:08:03', ''),
(40, 'Marvikhan', 'Marvikhan12', 'kids12345', 'images/Marvikhan12.jpg', 'Marvi Khan', 'Girl', 'Teacher', 'karachi', 'Habib Public School', '030XXXXX', 'karachi', '2005-04-08', '2017-12-19 01:08:03', ''),
(41, 'Saher_salahudin Teacher', 'Saher12', 'kids123456', 'images/Saher12.jpg', 'Saher Salahudin', 'Girl', 'Teacher', 'karachi', 'Habib Public School', '0346XXXXXXX', 'karachi', '1999-11-12', '2017-12-19 01:08:03', ''),
(42, 'Mir_Balach', 'Balach12', ' kids1234', 'images/dp.png', 'Mir Asim Faizi', 'Boy', 'B-4', 'karachi', 'Habib Public School', '0345XXXXXXX', 'karachi', '0000-00-00', '2017-12-19 01:08:03', ''),
(43, 'Shezil_Imrani', 'Shezil12', 'kids1212', 'images/dp.png', 'Shezil Imrani', 'Boy', 'B-6', 'karachi', 'Habib Public School', '0333XXXXX', 'karachi', '0000-00-00', '2017-12-19 01:08:03', ''),
(44, 'Waleed_Kashif', 'Waleed12', ' kids1313', 'images/dp.png', 'Waleed Kashif', 'Boy', 'B-6', 'Karachi', 'Habib Public School', '0322XXXXXXX', 'karachi', '0000-00-00', '2017-12-19 01:08:03', ''),
(45, 'Anas_Malik', 'Anas12', 'kids1414', 'images/dp.png', 'Anas Malik', 'Boy', 'B-6', 'karachi', 'Habib Public School', '03', 'karachi', '0000-00-00', '2017-12-19 01:08:03', ''),
(62, 'dazzling_jannat ', 'dazzling jannat ', 'anmol001', 'images/dazzling jannat .jpg', 'Dazzling Jannat', 'Girl', 'G-4', 'Karachi', 'Habib Public School', '0304XXXXXXX', 'karachi', '0000-00-00', '2017-12-21 00:11:16', ''),
(81, 'Brishk_sharjeel', 'brishksharjeel', '123456', 'images/dp.png', 'Brishk Sharjeel', 'Girl', 'G-4', 'Karachi', 'Habib Public School', '030XXXXX', 'karachi', '0000-00-00', '2018-01-13 06:32:38', ''),
(82, 'Nufail Khan kakar', 'nufail12', 'nufail5584', 'images/a1.png', 'Nufail Khan kakar', 'Boy', 'B-5', 'B-146 block J North Nazimabad Karachi', 'Anglo Model School', '000000000', 'Karachi', '2010-02-27', '2018-02-17 08:11:06', ''),
(83, 'Zamraiz khan', 'zamraiz12', 'zamraiz215', 'images/5.jpg', 'Zamraiz khan', 'Boy', 'B-5', 'B-146 Block J North Nazimabad', 'Anglo Model School', '000000000', 'Karachi', '2010-07-14', '2018-02-17 08:15:17', ''),
(85, 'Ahtisham', 'aht125', '125', 'images/daniyal12.jpg', 'Faran', 'Naeem', '5', 'Orangi town', 'Good Liuck', '03113201532', 'Karachi', '0000-00-00', '2020-06-21 13:39:21', ''),
(86, 'Ahtisham', 'aht125', '125', 'images/daniyal12.jpg', 'Faran', 'Naeem', '5', 'Orangi town', 'Good Liuck', '03113201532', 'Karachi', '2009-05-05', '2020-06-21 13:39:37', ''),
(100, 'Zayyan Khan', 'zayyan12', 'zayyan221', 'images/2.jpg', 'Zayyan Khan', 'Boy', 'B-5', 'B-146 Block J North Nazimabad', 'Anglo Model School', '000000000', 'Karachi', '0000-00-00', '2018-02-17 08:17:24', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `friends`
--
ALTER TABLE `friends`
  ADD PRIMARY KEY (`f_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `friends`
--
ALTER TABLE `friends`
  MODIFY `f_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
