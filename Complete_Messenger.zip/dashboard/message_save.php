<?php 
 include('session.php'); 
 

if(isset($_GET['chatmsg']) !='' ||  isset($_GET['to']) !='')
{
	echo $to = $_GET['to'];
	     $text =$_GET['chatmsg'];
	     $logined_id =  $userRow['userId'];


      $da = @$ext=strtolower(end(explode(".",$_FILES['imgfile']['name'])));
        if($ext == "png" || $ext == "jpg" || $ext == "jpeg")
        {
            $newname=rand()."."  .$ext;
            $path="./chat_image/".$newname;
            move_uploaded_file($_FILES['imgfile']['tmp_name'],$path); 
        } 
        if($da =="")
        {
            $Query = "INSERT INTO  dbo_text (`sender_id`,`to_id`,`text`,`type`) VALUES ('$logined_id','$to','$text','Unread')";
              $res = mysqli_query($conn,$Query);
        }
        else
        {
              $Query = "INSERT INTO  dbo_text (`sender_id`,`to_id`,`text`,`filepic`,`type`) VALUES ('$logined_id','$to','$text','$path','Unread')";
        	  $res = mysqli_query($conn,$Query);
        }
             
}
else
{
     $da = @$ext=strtolower(end(explode(".",$_FILES['imgfile']['name'])));
        if($ext == "png" || $ext == "jpg" || $ext == "jpeg")
        {
            $newname=rand()."."  .$ext;
            $path="./chat_image/".$newname;
            move_uploaded_file($_FILES['imgfile']['tmp_name'],$path); 
        } 
       $Query = "INSERT INTO  dbo_text (`sender_id`,`to_id`,`text`,`filepic`,`type`) VALUES ('$logined_id','$to','$text','$path','Unread')";
              $res = mysqli_query($conn,$Query);
}



?>