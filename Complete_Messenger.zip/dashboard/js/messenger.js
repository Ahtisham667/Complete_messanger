 <script>

                    function communication(x) {
                  //alert('ddd');

                  var xhttp = new XMLHttpRequest();
                  xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                      document.getElementById("communications").innerHTML = this.responseText;
                       
                    }
                  };
                  xhttp.open("GET","start_chat.php?userId=<?php echo $userRow['userId']; ?>&to="+x,true);
                  xhttp.send();
                }


                  $(document).ready(function(){ 
             
                      $('#messengerform').on('submit', function(e){
                    
                           e.preventDefault();   
                           $.ajax({  
                                 url:"message_save.php?to="+document.getElementById('to').value+"&chatmsg="+document.getElementById('chatmsg').value,
                                method:"POST",  
                                data:new FormData(this),  
                                contentType:false,  
                                //cache:false,  
                                processData:false,  
                                success:function(data)  
                                {   
                                $('#to').val(data);   
                                $('#chatmsg').val("");
                                $('#imgfile').val("");  

                                 displayChat();

                           
                               
                                              }
                                         }) 
                                    });   
                               });  

                 
                    function displayChat(){

                          var to = $('#to').val();
                          var userId = <?php echo  $userRow['userId'];  ?> 
                          $.ajax({
                            url: 'start_chat.php',
                            type: 'GET',
                            async: false,
                            data:{
                              to: to,
                              userId: userId,
                            },
                            success: function(response){
                               // alert('ssss');
                                  $('#communications').html(response);
                           document.getElementById('communications').scrollTop =  document.getElementById('communications').scrollHeight
                              
                           
                            }
                          });
                           }

                  </script>

                  <script>
                  function showLoading()
                  {
                      document.getElementById("loading").style = "display: normal";
                      document.getElementById("videodis").style = "display: none";
                      document.getElementById("videodisa").style = "display: none";
                      document.getElementById("videodisi").style = "display: none";
                      document.getElementById("ta").style = "display: none";
                  }

                  function hideLoading()
                  {
                      document.getElementById("loading").style = "display: none";
                      document.getElementById("videodis").style = "display: normal";
                      document.getElementById("videodisa").style = "display: normal";
                      document.getElementById("videodisi").style = "display: normal";
                      document.getElementById("ta").style = "display: normal";
                  }
                </script>