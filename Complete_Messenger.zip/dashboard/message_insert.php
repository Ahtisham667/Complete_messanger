<?php

include('session.php');
      // $mess =  $_GET['to'];
      // $logined_id = $userRow['m_id'];
      // $messs = $_GET['mess'];
// if(isset($_GET['mess']) !='' ||  isset($_GET['to']) !='')
// {

//        echo $to =  $_GET['to'];
//             $logined_id = $userRow['m_id'];
//             $text = $_GET['mess'];


//       $da = @$ext=strtolower(end(explode(".",$_FILES['imgfile']['name'])));
//         if($ext == "png" || $ext == "jpg" || $ext == "jpeg")
//         {
//             $newname=rand()."."  .$ext;
//             $path="./files_image/".$newname;
//             move_uploaded_file($_FILES['imgfile']['tmp_name'],$path); 
//         } 
//         if($da =="")
//         {
//             $Query = "INSERT INTO  dbo_text (`sender_id`,`to_id`,`text`,`type`) VALUES ('$logined_id','$to','$text','Unread')";
//               $res = mysqli_query($conn,$Query);
//         }
//         else
//         {
//               $Query = "INSERT INTO  dbo_text (`sender_id`,`to_id`,`text`,`filepic`,`type`) VALUES ('$logined_id','$to','$text','$path','Unread')";
//         	  $res = mysqli_query($conn,$Query);
//         }
             
// }
// else
// {
//      $da = @$ext=strtolower(end(explode(".",$_FILES['imgfile']['name'])));
//         if($ext == "png" || $ext == "jpg" || $ext == "jpeg")
//         {
//             $newname=rand()."."  .$ext;
//             $path="./files_image/".$newname;
//             move_uploaded_file($_FILES['imgfile']['tmp_name'],$path); 
//         } 
//        $Query = "INSERT INTO  dbo_text (`sender_id`,`to_id`,`text`,`filepic`,`type`) VALUES ('$logined_id','$to','$text','$path','Unread')";
//               $res = mysqli_query($conn,$Query);
// }



// if(isset($_POST['msg']) !='')
// {

//             $to =  $_POST['to'];
//             $logined_id = $userRow['m_id'];
//             $text = $_POST['msg'];


//             $Query = "INSERT INTO  dbo_text (`sender_id`,`to_id`,`text`,`type`) VALUES ('$logined_id','$to','$text','Unread')";
//               $res = mysqli_query($conn,$Query);
        
      
             
// }
// else
// {
//    echo "SomeThink Wrong";
// }
?>

<?php

      // $mess =  $_GET['to'];
      // $logined_id = $userRow['m_id'];
      // $messs = $_GET['mess'];
if(isset($_GET['mess']) !='' ||  isset($_GET['to']) !='')
{

 echo $to =  $_GET['to'];
      $logined_id = $userRow['userId'];
       $text = $_GET['mess'];


      $da = @$ext=strtolower(end(explode(".",$_FILES['imgfile']['name'])));
        if($ext == "png" || $ext == "jpg" || $ext == "jpeg")
        {
            $newname=rand()."."  .$ext;
            $path="./files_image/".$newname;
            move_uploaded_file($_FILES['imgfile']['tmp_name'],$path); 
        } 
        if($da =="")
        {
            $Query = "INSERT INTO  dbo_text (`sender_id`,`to_id`,`text`,`type`) VALUES ('$logined_id','$to','$text','Unread')";
              $res = mysqli_query($conn,$Query);
        }
        else
        {
              $Query = "INSERT INTO  dbo_text (`sender_id`,`to_id`,`text`,`filepic`,`type`) VALUES ('$logined_id','$to','$text','$path','Unread')";
        	  $res = mysqli_query($conn,$Query);
        }
             
}
else
{
     $da = @$ext=strtolower(end(explode(".",$_FILES['imgfile']['name'])));
        if($ext == "png" || $ext == "jpg" || $ext == "jpeg")
        {
            $newname=rand()."."  .$ext;
            $path="./files_image/".$newname;
            move_uploaded_file($_FILES['imgfile']['tmp_name'],$path); 
        } 
       $Query = "INSERT INTO  dbo_text (`sender_id`,`to_id`,`text`,`filepic`,`type`) VALUES ('$logined_id','$to','$text','$path','Unread')";
              $res = mysqli_query($conn,$Query);
}



?>








