<?php include('session.php'); ?>
<?php

?>
<!doctype html>
<html>
  <link href="./assets/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
      <script src="./assets/js/bootstrap.min.js"></script>
      <script src="./assets/js/jquery.min.js"></script>
      <!------ Include the above in your HEAD tag ---------->

      <link href="./assets/css/boootstrap.min.css" rel="stylesheet" />   
      <link href="css/style.css" rel="stylesheet" />   
      <link rel="stylesheet" href="./assets/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">


      <!--tab script-->
      <script src="./assets/js/bootsstrap.min.js"></script>
      <script src="./assets/js/jquerys.min.js"></script>
      <!--end tabs script-->
      <script
        src="./assets/js/jquery-3.4.1.js"
        integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
        crossorigin="anonymous"></script>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

 <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <head>
     
<div class="container-fluid" style="background-color:#069;border-bottom:2px padding:10px; 5solid #999; height:72px;"><br>
<?php include('fine_friend.php'); ?>
</div>
   
 <br><br>     



        <div class="container">
        <p id="requent_send"></p>
        </div>

       

                

             <script>
                function loadDocss() {
                  var xhttp = new XMLHttpRequest();
                  xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                      document.getElementById("requent_send").innerHTML = this.responseText;
                      
                    }
                  };
                  xhttp.open("GET", "accept.php", true);
                  xhttp.send();
                }

                $(document).ready(function(){ 
                  setInterval(function(){ 
                  
                  loadDocss();
                  
                  }, 1000);
                });

                
                </script>

                  <script>
                function confirmrequests(x) {
                  var xhttp = new XMLHttpRequest();
                  xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                      document.getElementById("btnn").innerHTML = this.responseText;
                      
                    }
                  };
                  xhttp.open("GET","confirm.php?confirm="+x,true);
                  xhttp.send();
                }

                $(document).ready(function(){ 
                  setInterval(function(){ 
                  
                  confirmrequests();
                  
                  }, 1000);
                });
                </script>


    </body>
</html>

     


           



