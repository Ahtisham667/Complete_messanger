      <?php //include('session.php'); ?>
     

      <!DOCTYPE html>
      <html>
      <head>
        <link href="./assets/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
      <script src="./assets/js/bootstrap.min.js"></script>
      <script src="./assets/js/jquery.min.js"></script>
      <!------ Include the above in your HEAD tag ---------->
      <link href="./assets/css/boootstrap.min.css" rel="stylesheet" />   
      <link href="css/style.css" rel="stylesheet" />   
      <link rel="stylesheet" href="./assets/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
      <!--tab script-->
      <script src="./assets/js/bootsstrap.min.js"></script>
      <script src="./assets/js/jquerys.min.js"></script>
      <!--end tabs script-->
      <script
        src="./assets/js/jquery-3.4.1.js"
        integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
        crossorigin="anonymous"></script>
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

      <!-- Begin emoji-picker Stylesheets -->
      <link href="../lib/css/emoji.css" rel="stylesheet">
      </head>
      
      <body>
 
  

      <div class="container-fluid" style="background-color:#069;border-bottom:2px padding:5px; solid #999; height:52px;"><br>
      <?php //include('fine_friend.php'); ?>
      </div>


          <?php //include('chatting_system.php'); ?>
           <?php include('messanger/index.php'); ?>



         <!-- <form method="post" class="form-container" id="mgsform" enctype="multipart/form-data"> 
         <p id="messages"></p>
         </form> -->
         
        <?php //include('style.php'); ?>
      <?php //include('fetch_data.php'); ?>

       
      </body>   
      </html>   

    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
    <script src="./assets/js/jquery-3.1.1.min.js" integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8=" crossorigin="anonymous"></script>    
    <script src="./assets/js/bbootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>

    <!-- Begin emoji-picker JavaScript -->
    <script src="../lib/js/config.js"></script>
    <script src="../lib/js/util.js"></script>
    <script src="../lib/js/jquery.emojiarea.js"></script>
    <script src="../lib/js/emoji-picker.js"></script>
    <!-- End emoji-picker JavaScript -->

    <script>
      $(function() {
        // Initializes and creates emoji set from sprite sheet
        window.emojiPicker = new EmojiPicker({
          emojiable_selector: '[data-emojiable=true]',
          assetsPath: '../lib/img/',
          popupButtonClasses: 'fa fa-smile-o'
        });
        // Finds all elements with `emojiable_selector` and converts them to rich emoji input fields
        // You may want to delay this step if you have dynamically created input fields that appear later in the loading process
        // It can be called as many times as necessary; previously converted input fields will not be converted again
        window.emojiPicker.discover();
      });
    </script>
    <script>
      // Google Analytics
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

      ga('create', 'UA-49610253-3', 'auto');
      ga('send', 'pageview');
    </script>


    <script>
$("#submitme").click(function () {
    setInterval(function() {
        $.ajax({
            url: "ajx.php",
            success: function (data) {
                $("#feedback").html(data + Math.random(999));
            }
        });
    }, 500);
    $('#jimbo').submit(); // submit the form manually
});
    </script>

    <script type="text/javascript">

             
    </script>