                <?php
                   
    include('session.php'); 


               $user_session_id = $userRow['m_id']; 
              


        if(isset($_POST['fetch'])){

        	 $mess =  $_POST['id'];

        
                  $query = "SELECT * FROM members
                  LEFT JOIN  `messenger`.`dbo_text` ON  `members`.`m_id` =  `dbo_text`.`sender_id`
                   WHERE  `dbo_text`.`to_id` = '$mess' or `dbo_text`.`sender_id` = '$mess'";
                  $rs = mysqli_query($conn,$query);
                  while($result = mysqli_fetch_array($rs)){
                     $to = $result['to_id']; 
                      $sender =  $result['sender_id'];
           
             ?>
            
               <?php if($user_session_id == $to ) { ?>


                   <p id="demos"></p>
                     <div class="row msg_container base_sent">
                        <div class="col-md-10 col-xs-10">
                            <div class="messages msg_sent">
                                <p><?php echo $result['text']; ?></p>
                                <time datetime="2009-11-13T20:00">Admininstrator • Yesterday 10:05:22</time>
                            </div>
                        </div>
                        <div class="col-md-2 col-xs-2 avatar">
                            <img src="<?php echo $result['m_image']; ?>" style="height:50px;" class="chatimg img-responsive ">
                        </div>
                    </div>


             <?php } elseif($mess == $to) { ?>


                 
                    <div class="row msg_container base_receive">
                        <div class="col-md-2 col-xs-2 avatar">
                            <img src="<?php echo $result['m_image']; ?>" style="height:50px;"  class="chatimg img-responsive ">
                        </div>
                        <div class="col-md-10 col-xs-10">
                            <div class="messages msg_receive">
                                <p><?php echo $result['text']; ?></p>
                                <time datetime="2009-11-13T20:00">Rajesh M • Yesterday 10:05:28</time>
                            </div>
                        </div>
                    </div>


              <?php } else { }?>  


                    
    <?php }  }  ?>