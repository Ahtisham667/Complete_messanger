   <style>
            @media only screen and (max-width : 540px) 
            {
                .chat-sidebar
                {
                    display: none !important;
                }
                
                .chat-popup
                {
                    display: none !important;
                }
            }
            
          
            .chat-sidebar
            {
                width: 200px;
                position: fixed;
                height: 100%;
                right: 0px;
                top: 0px;
                padding-top: 10px;
                padding-bottom: 10px;
                border: 1px solid rgba(29, 49, 91, .3);
            }
            
            .sidebar-name 
            {
                padding-left: 10px;
                padding-right: 10px;
                margin-bottom: 4px;
                font-size: 12px;
            }
            
            .sidebar-name span
            {
                padding-left: 5px;
            }
            
            .sidebar-name a
            {
                display: block;
                height: 100%;
                text-decoration: none;
                color: inherit;
            }
            
            .sidebar-name:hover
            {
                background-color:#e1e2e5;
            }
            
            .sidebar-name img
            {
                width: 32px;
                height: 32px;
                vertical-align:middle;
            }
            
            .popup-box
            {
                display: none;
                position: fixed;
                bottom: 0px;
                right: 220px;
                height: 355px;
                background-color: white;
                width: 300px;
                border: 1px solid rgba(29, 49, 91, .3);
            }
            
            .popup-box .popup-head
            {
                background-color: #6d84b4;
                padding: 5px;
                color: white;
                font-weight: bold;
                font-size: 14px;
                clear: both;
            }
            
            .popup-box .popup-head .popup-head-left
            {
                float: left;
            }
            
            .popup-box .popup-head .popup-head-right
            {
                float: right;
                opacity: 0.5;
            }
            
            .popup-box .popup-head .popup-head-right a
            {
                text-decoration: none;
                color: inherit;
            }
            
            .popup-box .popup-messages
            {
                height: 100%;
                overflow-y: scroll;
            }
            
     body
        {
            background-color: #e9eaed;
        }

        </style>
        <style>

.dot {
  height: 15px;
  width: 15px;
  background-color: #bbb;
  padding: 5px;
  border-radius: 50%;
}

</style> 
        <script>
            //this function can remove a array element.
            Array.remove = function(array, from, to) {
                var rest = array.slice((to || from) + 1 || array.length);
                array.length = from < 0 ? array.length + from : from;
                return array.push.apply(array, rest);
            };
        
            //this variable represents the total number of popups can be displayed according to the viewport width
            var total_popups = 0;
            
            //arrays of popups ids
            var popups = [];
        
            //this is used to close a popup
            function close_popup(id)
            {
                for(var iii = 0; iii < popups.length; iii++)
                {
                    if(id == popups[iii])
                    {
                        Array.remove(popups, iii);
                        
                        document.getElementById(id).style.display = "none";
                        
                        calculate_popups();
                        
                        return;
                    }
                }   
            }
        
            //displays the popups. Displays based on the maximum number of popups that can be displayed on the current viewport width
            function display_popups()
            {
                var right = 220;
                
                var iii = 0;
                for(iii; iii < total_popups; iii++)
                {
                    if(popups[iii] != undefined)
                    {
                        var element = document.getElementById(popups[iii]);
                        element.style.right = right + "px";
                        right = right + 320;
                        element.style.display = "block";
                    }
                }
                
                for(var jjj = iii; jjj < popups.length; jjj++)
                {
                    var element = document.getElementById(popups[jjj]);
                    element.style.display = "none";
                }
            }
            
            //creates markup for a new popup. Adds the id to popups array.
            function register_popup(id, name)
            {
                
                for(var iii = 0; iii < popups.length; iii++)
                {   
                    //already registered. Bring it to front.
                    if(id == popups[iii])
                    {
                        Array.remove(popups, iii);
                    
                        popups.unshift(id);
                        
                        calculate_popups();
                        
                        
                        return;
                    }
                }               
                
                var element = '<div class="popup-box chat-popup" id="'+ id +'">';
                element = element + '<div class="popup-head">';
                element = element + '<div class="popup-head-left">'+ name +'</div>';
                element = element + '<div class="popup-head-right"><a href="javascript:close_popup(\''+ id +'\');">&#10005;</a></div>';
                element = element + '<div style="clear: both"></div></div>';
                element = element + '<div class="popup-messages">';

              
                        element = element + '<form method="post" class="form-container"  id="mgsform">';
                        element = element + '<div class="input-group ">';
                        element = element + '<input id="to" hidden="" name="to" type="text" value="'+ id +'" class="form-control input-sm" placeholder="Type Message..." />';
                        element = element + '<input id="text" style="margin-top:293px;" name="text" type="text" class="form-control input-sm" placeholder="Type Message..." />';
                        element = element + '<span class="input-group-btn">';
                        element = element + '<button type="submit" style="margin-top:293px;" class="btn btn-warning btn-sm" id="btn" >Send</button>';
                        element = element + '</span>';
                        element = element + '</div>';
                        element = element + '</form>';

                        element = element + '</div></div>';
                
                document.getElementsByTagName("body")[0].innerHTML = document.getElementsByTagName("body")[0].innerHTML + element;  
        
                popups.unshift(id);
                        
                calculate_popups();


                
            }
            
            //calculate the total number of popups suitable and then populate the toatal_popups variable.
            function calculate_popups()
            {
                var width = window.innerWidth;
                if(width < 540)
                {
                    total_popups = 0;
                }
                else
                {
                    width = width - 200;
                    //320 is width of a single popup box
                    total_popups = parseInt(width/320);
                }
                
                display_popups();
                
            }
            
            //recalculate when window is loaded and also when window is resized.
            window.addEventListener("resize", calculate_popups);
            window.addEventListener("load", calculate_popups);
            
        </script>
 <?php  
 
              $xxx = $userRow['m_id'];
                 $Query="SELECT  `members`.`m_id` ,  `members`.`m_name` ,`members`.`m_image`,`members`.`m_status`, `friends`.`f_id` , `friends`.`m_id_two` ,
                `friends`.`m_id_one` , `friends`.`status` 
                  FROM members
                  LEFT JOIN  `messenger`.`friends` ON  `members`.`m_id` =  `friends`.`m_id_two` OR `members`.`m_id` = `friends`.`m_id_one`
                   WHERE  `friends`.`status` = 'Accept'"; 
                  $rs = mysqli_query($conn,$Query);
                  while($users = mysqli_fetch_array($rs)){
                    $xxx
                ?>
   
             <?php if($Query){ ?>

                  <?php if($users['m_id'] == $xxx){} elseif($users['m_id_two'] == $xxx || $users['m_id_one'] == $xxx) { ?>

            <div class="sidebar-name" style="border-bottom: 2px solid gray;margin-top:5px;">
                <!-- Pass username and display name to register popup -->
                 <a href="javascript:register_popup('<?php echo $users['m_id']; ?>', '<?php echo $users['m_name']; ?>');">
                    <img style="border-radius:50px;" width="30" height="30" src="<?php echo $users['m_image']; ?>" />   
                     <span style="height: 3px;width: 3px;margin-top:18px;background-color: <?php echo $users['m_status']; ?> ;border-radius: 50%;display: inline-block;" class="dot"></span>
                    <span><?php echo $users['m_name']; ?></span>
                 </a>

            </div>


                      <?php } ?>

                   <?php } ?>
                
                <?php } ?>