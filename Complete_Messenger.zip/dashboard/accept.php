       
  <?php include('session.php'); ?>

                 <?php  $xxx = $userRow['userId']; ?>

               <?php  

                 $Query="SELECT  `users`.`userId` ,  `users`.`userName` ,`users`.`image`, `friends`.`f_id` , `friends`.`m_id_two` ,
                `friends`.`m_id_one` , `friends`.`status` 
                  FROM users
                  LEFT JOIN  `kidsbook_kidsbook`.`friends` ON  `users`.`userId` =  `friends`.`m_id_one`  
                   WHERE `friends`.`status` = 'Panding'"; 
                  $rs = mysqli_query($conn,$Query);
                  while($user = mysqli_fetch_array($rs)){
                   $xxx
                ?>
   
             <?php if($Query){ ?>

              <?php if($user['m_id_two'] == $xxx){ ?>
                   
               
        
                       <div class="row"  style="background-color:#f5f5f5; padding:5px; border-bottom: 1px solid #e7e7e7; padding:10px;margin-bottom:5px;">
                           
                           <div class="col-sm-2" ></div><!--end of col-sm-1-->
                            <div class="col-sm-1" style="border:px solid;">
                              <img style="border-radius:50px; width:40px; height:40px;" src="<?php echo $user['image'];  ?>" alt="Picture">
                            </div><!--end of col-sm-2-->


                            <div class="col-sm-2" style="border:px solid;">
                             <p style="top:10px;"><?php echo $user['userName']; ?></p>
                            </div><!--end of col-sm-8-->


                            <div class="col-sm-2" style="border:px solid;">
                            <button style="margin-left:110px; margin-top:-2px;" type="submit" onclick="confirmrequests(<?php echo $user['f_id']; ?>)" class="btn btn-success">
                            Confirm
                            </button>
                            </div><!--end of col-sm-2-->
                             <div class="col-sm-5" ></div><!--end of col-sm-2-->


                          </div><!--end of row--> 
                     <?php } ?>

                   <?php } ?>
                
                <?php } ?>


                

