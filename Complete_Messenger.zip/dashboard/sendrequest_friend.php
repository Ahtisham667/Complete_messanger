<?php
include('session.php');

  $logined_id = $userRow['m_id'];
  $reguesed_id = $_GET['request'];




		if($logined_id !="" && $reguesed_id !="")
		{
		    $Query = "INSERT INTO  friends (`m_id_one`,`m_id_two`,`status`) VALUES ('$logined_id','$reguesed_id','Panding')";
		    $res = mysqli_query($conn,$Query);
		}
		else
		{
			echo "SomeThink Error";
		}
?>