       
<?php include('session.php'); ?>

<?php  $m_id = $userRow['userId']; ?>

               <?php  

                $Query="SELECT  `users`.`userId` ,  `users`.`userName` ,`users`.`image` , `friends`.`m_id_two` ,
                `friends`.`m_id_one` , `friends`.`status` 
                  FROM users
                  LEFT JOIN  `kidsbook_kidsbook`.`friends` ON   `users`.`userId` =  `friends`.`m_id_two` 
                  where `friends`.`m_id_one` = '$m_id' and `friends`.`status` = 'Panding' ORDER BY userId DESC";


                   // $Query = "SELECT *  FROM friends WHERE m_id_one = '$m_id'";
                   $rs = mysqli_query($conn,$Query);
                   //echo mysqli_error($conn);
                   while($user = mysqli_fetch_array($rs)){

                   $sender_id =  $user['userId'];

                

             
                ?>
  
                  <?php  $user['userId']; ?>
                          
                          <div class="row"  style="background-color:#f5f5f5; padding:5px; border-bottom: 1px solid #e7e7e7;padding:10px;margin-bottom:5px;">
                            <div class="col-sm-2" style="border:px solid;">
                              <img style="border-radius:50px; width:40px; height:40px;" src="<?php echo $user['image']; ?>" alt="Picture">
                            </div><!--end of col-sm-2-->
                            <div class="col-sm-4" style="border:px solid;">
                              
                             <p style="top:10px;"><?php echo $user['userName']; ?></p>
                               
                            </div><!--end of col-sm-8-->
                            <div class="col-sm-6" style="border:px solid;">
                              

                               <button disabled style="" type="submit" onclick="sendrequests(<?php //echo $user['m_id']; ?>)" class="btn btn-warning btn-xs">
                        
                                 Send Request Friend 

                                </button> 
                            </div><!--end of col-sm-2-->
                          </div><!--end of row--> 
                        

   

<?php } ?>















<?php
// $m_id=$_GET['m_id'];
   
//                    $Query = "SELECT * FROM members 
//                   WHERE `members.m_id` NOT IN (SELECT * FROM friends WHERE `friends.m_id_two` = '$xxx')
//                   AND `members.m_id` NOT IN (SELECT * FROM friends WHERE `friends.m_id_one` = '$xxx')
//                   AND `members.m_id` <> '$xxx'";

                  ?>