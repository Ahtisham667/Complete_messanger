<?php 

$conn = mysqli_connect("Localhost","root","","messenger");

// if($conn)
// {
// 	echo "string";
// }

if(isset($_POST["done"])){
	 $to = $_POST['username'];
	 $comment =$_POST['comment'];
	  $sender =$_POST['sender'];

	$result = "INSERT INTO dbo_text(`sender_id` , `to_id` , `text`) VALUES ('$sender', '$to' , '$comment' )";
	$s = mysqli_query($conn,$result);
	
}

if(isset($_POST['display']))
{
	$query = mysqli_query($conn , "SELECT * FROM dbo_text");
	while ($row = mysqli_fetch_array($query)) {

		?>

		<h6><?php echo $row['text']; ?></h6>
<?php
	
	}
}


?>