<?php
	include('session.php');
	if(isset($_POST['fetch'])){


		
		$mess = $_POST['id'];
		$user_session_id = $_POST['session'];
		


        if($mess !=""){

        
                  $query = "SELECT `users`.`userId` ,  `users`.`userName` , `users`.`image` , `dbo_text`.`type` ,`dbo_text`.`text` ,  `dbo_text`.`to_id` , `dbo_text`.`sender_id`  FROM users
                  LEFT JOIN  `kidsbook_kidsbook`.`dbo_text` ON  `users`.`userId` =  `dbo_text`.`sender_id`
                   WHERE  `dbo_text`.`to_id` = '$mess' or `dbo_text`.`sender_id` = '$mess'";
                  $rs = mysqli_query($conn,$query);
                  while($result = mysqli_fetch_array($rs)){
                     $to = $result['to_id']; 
                      $sender =  $result['sender_id'];
                      $readUnred = $result['type'];
           
             ?>
             
               <?php if($user_session_id == $to ) { ?>



				<li class="sent">
					<img style="width:30px;height:30px;" src="<?php echo $result['image']; ?>" alt="" />
					<p><?php echo $result['text']; ?> <i class="fal fa-check-double"></i></p>
					<i> <?php //echo $result['type']; ?> </i>
				</li>
				
			

                  <?php } elseif($mess == $to) { ?>


            
				<li class="replies">
					<img style="width:30px;height:30px;" src="<?php echo $result['image']; ?>" alt="" />
					<p>
						<?php if($readUnred == "Unread") { ?>

						<i  class="fa fa-check" aria-hidden="true"></i> 

						<?php }  elseif ($readUnred == "Read") { ?>

						<i style="color:blue;" class="fa fa-check" aria-hidden="true"></i> 

						<?php } ?>

						<?php echo $result['text']; ?>

					</p>
					<i> <?php //echo $result['type']; ?> </i>
				</li>
			
                  


              <?php } else { }?>  

                                        
    <?php }  } 
		
	}	


?>