       
<?php include('session.php'); ?>

<?php  $m_id = $userRow['userId']; ?>

               <?php  

                 // $Query = "SELECT * FROM members 
                 //   WHERE `members.m_id` NOT IN (SELECT * FROM friends WHERE  `friends.m_id_two` = '$xxx')
                 //   AND `members.m_id` NOT IN (SELECT * FROM friends WHERE `friends.m_id_one` = '$xxx')
                 //   AND `members.m_id` <> '$xxx'";

                   $Query = "SELECT users.userId , users.image , users.userName,users.address,users.class FROM users 
                    WHERE users.userId NOT IN (SELECT friends.m_id_one FROM friends WHERE friends.m_id_two = '$m_id') 
                    AND users.userId NOT IN (SELECT friends.m_id_two FROM friends WHERE friends.m_id_one = '$m_id')
                    AND users.userId <> '$m_id'";
                    
                  $rs = mysqli_query($conn,$Query);
                  echo mysqli_error($conn);
                  while($user = mysqli_fetch_array($rs)){
                  
             
                ?>
  
                  <?php  $user['userId']; ?>
                          
                          <div class="row"  style="background-color:#f5f5f5; padding:5px; border-bottom: 1px solid #e7e7e7">
                            <div class="col-sm-2" style="border:px solid;">
                              <img style="border-radius:50px; width:40px; height:40px;" src="<?php echo $user['image']; ?>" alt="Picture">
                            </div><!--end of col-sm-2-->
                            <div class="col-sm-4" style="border:px solid;">
                              
                             <p style="top:10px;"><?php echo $user['userName']; ?></p>
                               
                            </div><!--end of col-sm-8-->
                            <div class="col-sm-6" style="border:px solid;">
                              
                               <button style="" type="submit" onclick="sendrequests(<?php echo $user['userId']; ?>)" class="btn btn-primary btn-xs">
                                
                                 <?php //echo $user['status']; ?> 
                                <?php //if (strlen($user['status']) == 0 ) {  ?>

                                Add Friend 

                                <?php //} else {?>
                                
                                <?php //echo $user['status']; ?>
                                 
                                <?php //} ?>

                                </button>
                            </div><!--end of col-sm-2-->
                          </div><!--end of row--> 
                        

    <?php } ?>

















<?php
// $m_id=$_GET['m_id'];
   
//                    $Query = "SELECT * FROM members 
//                   WHERE `members.m_id` NOT IN (SELECT * FROM friends WHERE `friends.m_id_two` = '$xxx')
//                   AND `members.m_id` NOT IN (SELECT * FROM friends WHERE `friends.m_id_one` = '$xxx')
//                   AND `members.m_id` <> '$xxx'";

                  ?>