



            <script>
            function funi(str)
            {
                
                var name = document.getElementById('txt').value;

                 if (name == "") { 
                 document.getElementById("data").innerHTML = "";
                 return;
                 }

                ahtisham = new XMLHttpRequest();
                ahtisham.open("GET","find.php?val="+name,true);
                ahtisham.send();
                ahtisham.onreadystatechange=statechanged;
            }
            function statechanged()
            {
                if(ahtisham.readyState==4 && ahtisham.status==200)
                {
                    document.getElementById('data').innerHTML=ahtisham.responseText;
                }
            }

            </script>

              <script>
                function sendrequests(x) {
                  var xhttp = new XMLHttpRequest();
                  xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                      document.getElementById("btn").innerHTML = this.responseText;
                      
                    }
                  };
                  xhttp.open("GET","sendrequest_friend.php?request="+x,true);
                  xhttp.send();
                }

                </script>

                
             
                <div class="row">
                  
                    <div class="col-sm-4">

                      <input style="margin-top:-5px;"  type="text" id="txt" onkeyup="funi(this.value)" onselect="funi()" autocomplete="off" class="form-control form-control-sm" style="width:100%" placeholder="Find Friends">
                      <div style="position:absolute;z-index:9999;width:94%;max-height:10px;background-color:#FFF;">
                        
                            <div id="data"></div>
                       
                      </div>
                    </div>

                    <div class="col-sm-1"></div>

                    <div class="col-sm-6">
                      <!-- <a href="chating.php"><buttton type="button" value="View Friend" class="btn btn-primary btn-sm">Home</button></a> -->
                     <div class="btn-group btn-group-toggle">
                      <label class=" active">
                      <!-- <a href="index.php" style="text-decoration:none;color:white;"> <button type="button" class="btn btn-primary btn-sm">Home</button> </a> -->
                      </label>

                      <label class="">
                      <a href="view_friend.php" style="text-decoration:none;color:white;"><button type="button" class="btn btn-primary btn-sm">Friend</button>  </a>
                      </label>
               
                      <label class="">
                      <a href="facebook_live.php" style="text-decoration:none;color:white;"><button type="button" class="btn btn-primary btn-sm">Messenger</button>  </a>
                      </label>
                     </div>

                     <label class="">
                     <a href="friend_request.php" style="text-decoration:none;color:white;">
                     <button type="button" class="btn btn-primary">
                      Notifications <span class="badge badge-light"><p id="notifications"></p></span>
                     </button>
                     </a>



                     <label class="">
                      <a href="../logout.php?logout" style="text-decoration:none;color:white;"><button type="button" class="btn btn-primary btn-sm">Logout</button>  </a>
                      </label>
               


                      </div>

                    </div>


                    <div class="col-sm-1"></div>


                </div>

                <script>
                $( document ).ready(function() {
                notifications();
                });



                 function notifications(){

                          var userId = <?php echo $user_id;  ?> 
                          $.ajax({
                            url: 'notification.php',
                            type: 'GET',
                            async: false,
                            data:{
                              userId: userId,
                            },
                            success: function(response){

                                  $('#notifications').html(response);
                        
                            }
                          });
                           }


                               $(document).ready(function(){ 
                                setInterval(function(){ 
                                
                                notifications();
                                
                                }, 1000);
                                });
                </script>


    



   