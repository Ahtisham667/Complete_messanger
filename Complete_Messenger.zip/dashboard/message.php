<?php include('session.php'); ?>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>  


<?php 


  $user_session_id = $userRow['m_id']; 
   $mess =  $_GET['message_id'];


	      if($mess !=""){   

        
                  $query = "SELECT * FROM members
                  LEFT JOIN  `messenger`.`dbo_text` ON  `members`.`m_id` =  `dbo_text`.`sender_id`
                   WHERE  `dbo_text`.`to_id` = '$mess' or `dbo_text`.`sender_id` = '$mess'";
                  $rs = mysqli_query($conn,$query);
                  while($result = mysqli_fetch_array($rs)){

                      $to = $result['to_id']; 
                      $sender =  $result['sender_id'];



               // $querys = mysqli_query($conn,"SELECT * FROM dbo_text where to_id = '$to'");
               //  while($Reciver =  mysqli_fetch_array($querys)) {}
		   
		
             ?>

                         

                            <div class="chatbox__body" id="streamTitle">
                              <div class="chatbox__body__message chatbox__body__message--right">
                                  
     <!--    <div class="chatbox_timing" style="border:px solid;">
        <ul>
        <li><a href="#"><i class="fa fa-calendar"></i> 22/11/2018</a></li>
          <li><a href="#"><i class="fa fa-clock-o"></i> 7:00 PM</a></a></li>
        </ul>
        </div>
  
            <img src="https://www.gstatic.com/webp/gallery/2.jpg" alt="Picture">
      <div class="clearfix"></div>
      <div class="ul_section_full">
      <ul class="ul_msg">
      <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </li>
      </ul>
      <div class="clearfix"></div>
      <ul class="ul_msg2">
        <li><a href="#"><i class="fas fa-check-double"></i></a></li>
      <li><a href="#"><i class="fa fa-trash chat-trash"></i></a></li>
      </ul>
      </div> -->


       
        
                                 <ul>
                                  <?php if($user_session_id == $to ) { ?>

                                  <li>

                                 
                                  <?php if($result['filepic'] != '') { ?> 


                                    <li  style="padding:5px; height:154px; background-color:white;" class="him">
                                  
                                     <img id="myImg" src="<?php echo $result['filepic']; ?>" alt="Snow" style="width:100px; height:140px; border-radius: 10px; ">
                                
                                   </li>

                                  <li style="padding:5px;" class="him"><?php echo $result['text']; ?></li>


                                  <?php } else { ?>

                                <li style="padding:5px;" class="him"><?php echo $result['text']; ?></li>

                                  <?php } ?>

                                </li>
 
                                 

                                <?php } elseif($mess == $to) { ?>

                                <?php $sign = mysqli_query($conn,"UPDATE dbo_text SET type='read' WHERE sender_id='$to'"); ?>

                              <li>
                               <!-- <b id="demos"></b> -->

                               <?php if($result['filepic'] !='') { ?>
                               
                                   <li  style="padding:5px; height:154px; background-color:white; border:2px solid;" class="me">
                                  
                                     <img id="myImg" src="<?php echo $result['filepic']; ?>" alt="Snow" style="width:100px; height:140px; border-radius: 10px; margin-left:-90px; border:2px solid;">
                                
                                   </li>

                                  <li style="padding:5px; margin-top:0px;" class="me"><samp> <?php echo $result['text']; ?></samp>&nbsp;&nbsp;

                                  <?php if($result['type'] == "read") { ?>

                                  <i style="color:blue;" class='fas fa-check-double'></i>

                                  <?php } elseif ($result['type'] == "Unread") { ?>

                                  <i class='fas fa-check-double'></i>

                                  <?php } ?>

                                  </li>


                                <?php } else { ?>  

                                  <li style="padding:5px; margin-top:0px;" class="me"><samp><?php echo $result['text']; ?></samp>&nbsp;&nbsp;
                                  
                                  <?php if($result['type'] == "read") { ?>

                                  <i style="color:blue;" class='fas fa-check-double'></i>

                                  <?php } elseif ($result['type'] == "Unread") { ?>

                                  <i class='fas fa-check-double'></i>

                                  <?php } ?>
                                  
                                  <li>

                               <?php } ?>

                              </li>
                              
                                 <?php } ?>

                                </ul>

                              </div> 

  <!--    <div class="chatbox__body__message chatbox__body__message--left">
    <div class="chatbox_timing">
    <ul>
    <li><a href="#"><i class="fa fa-calendar"></i> 22/11/2018</a></li>
      <li><a href="#"><i class="fa fa-clock-o"></i> 7:00 PM</a></a></li>
    </ul>
    </div>
  
            <img src="https://www.gstatic.com/webp/gallery/2.jpg" alt="Picture">
      <div class="clearfix"></div>
      <div class="ul_section_full">
      <ul class="ul_msg">
      <li><strong>Person Name</strong></li>
      <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </li>
      </ul>
      <div class="clearfix"></div>
      <ul class="ul_msg2">
      <li><a href="#"><i class="fa fa-pencil"></i> </a></li>
      <li><a href="#"><i class="fa fa-trash chat-trash"></i></a></li>
      </ul>
      </div>
       
        </div> -->
                            </div>
 
                           
              <?php }  }  ?>
             


  
                                    <!-- <p id="chat_area"></p> -->
                                   
                                <!--     <div class="" style="border:px solid;">

                                     <div class="input-group" style="">
                                    <label class="newbtn" >
                                    <img src="images/icon.png" style="margin-left:50x; width:30px; height:30px;">
                                    <input id="pic" type="file" id="imgfile" name="imgfile">
                                    </label>
                                   </div>  

                                   <div class="input-group" style="margin-top:30px;">
                                    <input type="text" hidden=""  value="<?php echo $mess; ?>" name="to" id="to" >
                                    <input id="mess" name="mess" type="text"  class="form-control input-sm chat_set_height" placeholder="Type Message..." />
                                     <span class="input-group-btn">
                                        <button type="submit" style="margin-left:50x;" id="btn-chat" class="btn btn-warning " id="btn" >Send</button>
                                     </span>
                                   </div> -->

                                  

                                   </div>
                        
                           
                                     
 
<style>


#pic{
     display: none;
     width: 10px;
     height: 10px;
       }
       
 .newbtn{
         cursor: pointer;
      }
</style>
<script>
 $('.newbtn').bind("click" , function () {
        $('#pic').click();
 });
</script>
<style>

.navbar {
  position: fixed;
  width: 250px;
}

</style> 

<script>   
    function displayChat(){
    id = <?php echo $mess; ?>;
    alert(id);
    $.ajax({
      url: 'fetch_chat.php',
      type: 'POST',
      async: false,
      data:{
        id: id,
        fetch: 1,
      },
      success: function(response){
        $('#chat_area').html(response);
       
        // $("#chat_area").scrollTop($("#chat_area")[0].scrollHeight);
      }
    });
     }

       $(document).ready(function(){ 
         setInterval(function(){ 
                  
           displayChat();
                  
           }, 1000);
          });
</script>
        


